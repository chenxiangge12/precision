#include "global.h"
using namespace Rcpp;

Rcpp::NumericVector  mrl( NumericVector y, NumericVector cen);




